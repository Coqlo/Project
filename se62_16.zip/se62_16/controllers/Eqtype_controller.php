<?php
class EqtypeController
{
	public function index()
	{
		$EqtypeList = Eqtype::getAll();
		require_once('views/eqtype/index_eqtype.php');
    }
    
	public function search()
	{
		$key=$_GET['key'];
		$EqtypeList=Eqtype::search($key);
		require_once('views/eqtype/index_eqtype.php');
	}
    /*public function addEqtype()
	{

        $UserName=$_GET['UserName'];	
        $UserEmail=$_GET['UserEmail'];
		$UserTel=$_GET['UserTel'];
		$ActivityName = $_GET['ActivityName'];
		$Date=$_GET['Date'];
		$TimeStart=$_GET['TimeStart'];
        $TimeFinish=$_GET['TimeFinish'];
        $ActivityPrice=$_GET['ActivityPrice'];
		$ActivityID=$_GET['ActivityID'];
        Eqtype::add($UserName,$UserEmail,$UserTel,$ActivityName,$Date,$TimeStart,$TimeFinish,$ActivityPrice,$ActivityID);
		EqtypeController::index();
        
	}public function newEqtype()
	{
		
		$id=$_GET['TypeID'];
		$View1=View1::get($id);

		$ActivityList = Activity::getAll();
		require_once('views/Eqtype/newEqtype.php');
	}*/
    
}
?>