<?php
$controllers=array('pages'=>['home','error'], 'Eqtype'=>['index','search'], 'Equipment'=>['index','search'], 'History'=>['Allow','notAllow','detailHistory','index','newHistory','search','addHistory','indexhis','deleteConfirm','delete','update'],
'Manage'=>['index','search','newManage','addManage','updateForm','update','deleteConfirm','delete'],'Type'=>['index']);

function call($controller,$action)
{
	require_once("controllers/".$controller."_controller.php");
	switch($controller)
	{
		case "pages"		:	$controller = new PagesController();
								break;
		case "Eqtype"		:	require_once("models/EqtypeModel.php");
								$controller = new EqtypeController();
								break;
		case "Equipment"	:	require_once("models/EquipmentModel.php");
								require_once("models/EqtypeModel.php");
								$controller = new EquipmentController();
								break;
		case "History"		:	require_once("models/HistoryModel.php");
								require_once("models/EquipmentModel.php");
								require_once("models/EqtypeModel.php");
								$controller = new HistoryController();
								break;
		case "Manage"		:	require_once("models/ManageModel.php");
								require_once("models/EqtypeModel.php");	
								$controller = new ManageController();
								break;						
	}
	$controller->{$action}();
}
if(array_key_exists($controller,$controllers))
{	if(in_array($action,$controllers[$controller]))
	{ 	call($controller,$action); }
	else
	{	call('pages','error');	}
}
else
{	call('pages','error');	}
?>