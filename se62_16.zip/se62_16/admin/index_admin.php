
<?php

//error_reporting (E_ALL ^ E_NOTICE);	

if (isset($_GET['controller'])&&isset($_GET['action']))
{
	$controller = $_GET['controller'];
	$action = $_GET['action'];
}
else 
{
	$controller = 'pages';
	$action = 'home';
}?>
	
<html>
<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">
	<title>ระบบยืม-คืนอุปกรณ์</title>
</head>
	<style>
body  {
	width:100%;
  background-image: url("https://cdn.discordapp.com/attachments/611238647932518421/692459923845677227/bg01.jpg") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
	background-position: center;
	
}
.dropdown:hover>.dropdown-menu {
  display: block;
}

.dropdown>.dropdown-toggle:active {
    pointer-events: none;
}
		
.table{
	width: 100%;
	border-collapse: collapse;	
		}
.table td,.table th{
	padding: 12px 15px;
	border: 1px solid #ddd;
	text-align: center;
}
@media(max-width: 500px){
	.table thead{
		display: none;
	}
	.table, .table tbody, .table tr, .table td{
		display: block;
		width: 100%;
	}
	.table tr{
		margin-bottom:15px;
	}
	.table td{
		text-align: right;
		padding-left: 50%;
		text-align: right;
		position: relative;
	}
	.table td::before{
		content: attr(data-lable);
		position: absolute;
		left: 0;
		width: 50%;
		padding-left:15px;
		font-size:15px;
		font-weight: bold;
		text-align: left;
	}
}

</style>

<body >
<nav class="navbar navbar-expand-lg navbar-light " style="background-color: transparent !important;"> 
  	  <a class="navbar-brand" >
		<h3>ระบบยืม-คืนอุปกรณ์</h3><h5>ภาควิชาวิศวกรรมคอมพิวเตอร์</h5>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"> 
			<span class="navbar-toggler-icon"></span> 
		</button>
		<div class="collapse navbar-collapse" id="navbarSupportedContent1">
    			<ul class="navbar-nav mr-auto">
      				
    			</ul>
    		<ul class="navbar-nav px-3">
			<li class="nav-item"> 
					  <a class="nav-link" href="?controller=index.php">หน้าหลัก </a>
					</li>
     				<li class="nav-item"> 
					  <a class="nav-link" href="?controller=Manage&action=index"><i class="fas fa-cube"></i> การจัดการอุปกรณ์</a> 
					</li>
     				<li class="nav-item "> 
					  <a class="nav-link" href="?controller=History&action=index"><i class="fas fa-clipboard-list"></i> ประวัติการยืม-คืน</a>
					</li>
    				<li class="nav-item text-nowrap">
						<a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
    				</li>
  				</ul>
  			</div>
</nav>

<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script>
<script src="js/popper.min.js" type="text/javascript"></script>
<script src="js/bootstrap-4.3.1.js" type="text/javascript"></script>
</body>	
<?php require_once("routes.php");?> 
	

</html>	
	




	 



	 

