<?php
class ManageController
{
	public function index()
	{
		$ManageList = Manage::getAll();
		require_once('views/manage/index_manage.php');
    }
    
	public function search()
	{
		$key=$_GET['key'];
		$ManageList=Manage::search($key);
		require_once('views/manage/index_manage.php');
    }
    public function newManage()
    {
        $ManageList = Manage::getAll();
        $EqtypeList = Eqtype::getAll();
        require_once('views/manage/newManage.php');
	}
	public function addManage(){	
        
        $EquipmentName=$_GET['EquipmentName'];	
        $EquipmentID=$_GET['EquipmentID'];
        $Quantity = $_GET['Quantity'];
        $TypeID= $_GET['TypeID'];
        $EquipmentStatus=$_GET['EquipmentStatus'];
        $EquipmentDetail = $_GET['EquipmentDetail'];
       
        Manage::add($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail);
		ManageController::index();	
	}
	public function updateForm()
	{
        $EquipmentID=$_GET['EquipmentID'];
        $TypeID=$_GET['TypeID'];
        $Manage=Manage::get($EquipmentID);
        $Eqtype=Eqtype::get($TypeID);
        $ManageList=Manage::getAll();
        $EqtypeList=Eqtype::getAll();
        require_once('views/manage/updateForm.php');
	}
	public function update()
	{
        $EquipmentName=$_GET['EquipmentName'];	
        $EquipmentID=$_GET['EquipmentID'];
        $Quantity = $_GET['Quantity'];
        $TypeID = $_GET['TypeID'];
        $EquipmentStatus=$_GET['EquipmentStatus'];
        $EquipmentDetail = $_GET['EquipmentDetail'];

		Manage::update($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail);
		ManageController::index();
	}
	public function deleteConfirm()
	{
		$EquipmentID=$_GET['EquipmentID'];
		$Manage=Manage::get($EquipmentID);
		require_once('views/manage/deleteConfirm.php');
	}
	public function delete()
	{
			$EquipmentID=$_GET['EquipmentID'];
			Manage::delete($EquipmentID);
			ManageController::index();
	}

}
?>