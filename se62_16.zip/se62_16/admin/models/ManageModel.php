<?php
Class Manage{

public $EquipmentName;
public $EquipmentID; 
public $EquipmentDetail;
public $EquipmentStatus;
public $TypeID;
public $Quantity;


public function Manage($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail)
{
	$this->EquipmentName = $EquipmentName;
    $this->EquipmentID = $EquipmentID;
    $this->Quantity = $Quantity;
    $this->TypeID = $TypeID;
    $this->EquipmentStatus = $EquipmentStatus;
	$this->EquipmentDetail = $EquipmentDetail;
    
     
}


public static function getAll()
{
	$ManageList=[];
    require("connection_connect.php");
    $sql = "SELECT * FROM equipment ";
	$result = $conn->query($sql);
	
    while($my_row=$result->fetch_assoc())
    	{
            $EquipmentName=$my_row['EquipmentName'];
            $EquipmentID=$my_row['EquipmentID'];
            $Quantity=$my_row['Quantity'];
            $TypeID=$my_row['TypeID'];
            $EquipmentStatus=$my_row['EquipmentStatus'];
            $EquipmentDetail=$my_row['EquipmentDetail'];
            
            
			
      		$ManageList[] = new Manage($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail);
    	}
    	require("connection_close.php");
    	return $ManageList;
}  
public static function get($ID)
{
  require("connection_connect.php");
  $sql = "select * from equipment where EquipmentID='$ID'";
  $result=$conn->query($sql);

  $my_row = $result->fetch_assoc();
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $EquipmentDetail=$my_row['EquipmentDetail'];
  $EquipmentStatus=$my_row['EquipmentStatus'];
  $TypeID=$my_row['TypeID'];
  $Quantity=$my_row['Quantity'];
  
  require("connection_close.php");

  return new Manage($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail);
}

public static function search($key)
{
	$EquipmentList=[];
	require("connection_connect.php");
    $sql="select *from equipment 
    where ( EquipmentName like'%$key%' or EquipmentID like'%$key%'  or Quantity like'%$key%'or  TypeID like'%$key%' or EquipmentStatus like'%$key%'or EquipmentDetail like'%$key%'  )";
    $result=$conn->query($sql);
    
	while($my_row=$result->fetch_assoc())
	{
     
        $EquipmentID=$my_row['EquipmentID'];
        $EquipmentName=$my_row['EquipmentName'];
        $EquipmentStatus=$my_row['EquipmentStatus'];
        $Quantity=$my_row['Quantity'];
        $TypeID=$my_row['TypeID'];
        $EquipmentDetail=$my_row['EquipmentDetail'];
    
    $ManageList[]=new Manage($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail);
	}
	require("connection_close.php");
	return $ManageList;
}

public static function add($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail)
{	
    require("connection_connect.php");
    
    $sql = "insert into equipment(EquipmentName,EquipmentID,Quantity,TypeID,EquipmentStatus,EquipmentDetail)
    values ('$EquipmentName','$EquipmentID','$Quantity','$TypeID','$EquipmentStatus','$EquipmentDetail')";
    $result=$conn->query($sql);
    
    require("connection_close.php");
    return "add success $result rows";
}
public static function update($EquipmentName,$EquipmentID,$Quantity,$TypeID,$EquipmentStatus,$EquipmentDetail)
{
	
	require("connection_connect.php");
	$sql="UPDATE equipment SET EquipmentName = '$EquipmentName', Quantity = '$Quantity' ,TypeID = '$TypeID',EquipmentStatus = '$EquipmentStatus', EquipmentDetail = '$EquipmentDetail'
     WHERE EquipmentID = '$EquipmentID'";
	$result=$conn->query($sql);

	require("connection_close.php");
	return "update success $result row";
}
public static function delete($id)
{
    require("connection_connect.php");
    $sql="Delete from equipment	where EquipmentID='$id'";

    $result=$conn->query($sql);
    require("connection_close.php");
    return "delete success $result row";
}
        
}?>