<?php
Class Equipment{
public $EquipmentID ; 
public $EquipmentName;
public $EquipmentDetail;
public $EquipmentStatus;
public $EquipmentPrivilege;
public $TypeID;
public $Quantity;


public function Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentPrivilege,$TypeID,$Quantity)
{
	
	$this->EquipmentID = $EquipmentID;
    $this->EquipmentName = $EquipmentName;
    $this->EquipmentDetail = $EquipmentDetail;
    $this->EquipmentStatus = $EquipmentStatus;
    $this->EquipmentPrivilege = $EquipmentPrivilege;
    $this->TypeID = $TypeID;
	$this->Quantity = $Quantity;

}
public static function getAll()
{
	$EquipmentList=[];
    require("connection_connect.php");
    $sql = "SELECT * FROM equipment ";
	$result = $conn->query($sql);
	
    while($my_row=$result->fetch_assoc())
    	{
    		$EquipmentID=$my_row['EquipmentID'];
            $EquipmentName=$my_row['EquipmentName'];
            $EquipmentDetail=$my_row['EquipmentDetail'];
            $EquipmentStatus=$my_row['EquipmentStatus'];
            $EquipmentPrivilege=$my_row['EquipmentPrivilege'];
            $TypeID=$my_row['TypeID'];
            $Quantity=$my_row['Quantity'];
			
      		$EquipmentList[] = new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentPrivilege,$TypeID,$Quantity);
    	}
    	require("connection_close.php");
    	return $EquipmentList;
}  
public static function get($ID)
{
  require("connection_connect.php");
  $sql = "select * from equipment where EquipmentID='$ID'";
  $result=$conn->query($sql);

  $my_row = $result->fetch_assoc();
  $EquipmentID=$my_row['EquipmentID'];
  $EquipmentName=$my_row['EquipmentName'];
  $EquipmentDetail=$my_row['EquipmentDetail'];
  $EquipmentStatus=$my_row['EquipmentStatus'];
  $EquipmentPrivilege=$my_row['EquipmentPrivilege'];
  $TypeID=$my_row['TypeID'];
  $Quantity=$my_row['Quantity'];
 
  require("connection_close.php");

  return new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentPrivilege,$TypeID,$Quantity);
}
public static function search($key)
{
	$EquipmentList=[];
	require("connection_connect.php");
    $sql="select *from equipment 
    where (EquipmentID like'%$key%' or EquipmentName like'%$key%' or EquipmentDetail like'%$key%' or EquipmentStatus like'%$key%' or EquipmentPrivilege like'%$key%' or TypeID like'%$key%' or Quantity like'%$key%')";
    $result=$conn->query($sql);

	while($my_row=$result->fetch_assoc())
	{
        $EquipmentID=$my_row['EquipmentID'];
        $EquipmentName=$my_row['EquipmentName'];
        $EquipmentDetail=$my_row['EquipmentDetail'];
        $EquipmentStatus=$my_row['EquipmentStatus'];
        $EquipmentPrivilege=$my_row['EquipmentPrivilege'];
        $TypeID=$my_row['TypeID'];
        $Quantity=$my_row['Quantity'];
    
    $EquipmentList[]=new Equipment($EquipmentID,$EquipmentName,$EquipmentDetail,$EquipmentStatus,$EquipmentPrivilege,$TypeID,$Quantity);
	}
	require("connection_close.php");
	return $EquipmentList;
}

        
}?>