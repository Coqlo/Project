<?php
$servername = "localhost";
$username = "root";
$password = "0115e7ce";
$dbname = "se62_16";
$conn =  new mysqli($servername,$username,$password);
if($conn->connect_error){

	die ("Connection failed:".$conn->connect_error);
}

if(!$conn->select_db($dbname)){
	
	die ("Connection failed:".$conn->cnewonnect_error);
}
?>