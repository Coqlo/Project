
<?php

//error_reporting (E_ALL ^ E_NOTICE);	

if (isset($_GET['controller'])&&isset($_GET['action']))
{
	$controller = $_GET['controller'];
	$action = $_GET['action'];
}
else 
{
	$controller = 'pages';
	$action = 'home';
}?>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	<title>ระบบจองสนามแบดมินตันออนไลน์</title>
</head>
	<style>
body  {
	width:100%;
  background-image: url("https://cdn.discordapp.com/attachments/611238647932518421/691300390582485062/bg.jpg") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
	background-position: center;
	
}
.table{
	width: 100%;
	border-collapse: collapse;	
		}
.table td,.table th{
	padding: 12px 15px;
	border: 1px solid #ddd;
	text-align: center;
}
@media(max-width: 500px){
	.table thead{
		display: none;
	}
	.table, .table tbody, .table tr, .table td{
		display: block;
		width: 100%;
	}
	.table tr{
		margin-bottom:15px;
	}
	.table td{
		text-align: right;
		padding-left: 50%;
		text-align: right;
		position: relative;
	}
	.table td::before{
		content: attr(data-lable);
		position: absolute;
		left: 0;
		width: 50%;
		padding-left:15px;
		font-size:15px;
		font-weight: bold;
		text-align: left;
	}
}

</style>

<body >
<nav class="shadow navbar navbar-expand-lg navbar-dark bg-dark" style="background-color: #e2d224;"> 
  	  <a class="navbar-brand" href="./?controller=index.php">
    <img src="https://cdn.discordapp.com/attachments/611238647932518421/690917696161841192/logo.png" width="80" alt="">
		  ระบบจองสนามแบดมินตัน
  </a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"> 
			<span class="navbar-toggler-icon"></span> 
		</button>
 			<div class="collapse navbar-collapse" id="navbarSupportedContent1">
    			<ul class="navbar-nav mr-auto">
      				<li class="nav-item"> 
					  <a class="nav-link" href="./?controller=index.php">หน้าหลัก <span class="sr-only">(current)</span></a>
					</li>
     				<li class="nav-item"> 
					  <a class="nav-link" href="./?controller=BadmintonTable&action=index">ตารางแบดมินตัน</a> 
					</li>
     				<li class="nav-item "> 
					  <a class="nav-link" href="./?controller=RateBadminton&action=index">อัตราการใช้บริการ</a>
					</li>
	  				<li class="nav-item"> 
						<a class="nav-link" href="./?controller=Reserve&action=index">ข้อมูลการจอง</a>
					</li>
    			</ul>
    		<form class="form-inline my-2 my-lg-0">
      		<a href="login/loginform.php" class="btn btn-outline-success" role="button">Admin</a>
    		</form>
  			</div>
</nav>

<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script>
<script src="js/popper.min.js" type="text/javascript"></script>
<script src="js/bootstrap-4.3.1.js" type="text/javascript"></script>
</body>	
<?php require_once("routes.php");?> 
	

</html>	
	
