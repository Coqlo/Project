<html>
<head></head>
<body>
<form method="get" action="">
<label>ชื่อผู้จอง <input type="text" name="ReserveName" /> </label><br>
<label>เบอร์โทร <input type="text" name="ReserveTel" /> </label><br>
<label>อีเมลล์<input type="text" name="ReserveEmail" /> </label><br>
<label>ช่วงเวลาเริ่ม <input name="TimeStart"
 	value="<?php echo $Time->TimeStart; ?>"/> </label>>
<label> ถึง <input name="TimeFinish"
 	value="<?php echo $Time->TimeFinish; ?>"/> </label><br>
<label>BadmintonCourt <input name="BadmintonCourt"
    value="<?php echo $Badminton->BadmintonCourt; ?>" </label>
<label>TerminalGym <input name="TerminalGym"
    value="<?php echo $Badminton->TerminalGym; ?>" </label><br>



</body>
</html>




