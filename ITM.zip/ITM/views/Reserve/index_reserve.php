<html>
	<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</head>

	<body>
		<div class="container">
			<div><br></div>
			<table class="shadow table table-striped">
  			<thead class="thead-dark">
   				 <tr align='center' >
      				<th scope="col">ชื่อผู้จอง</th>
      				<th scope="col">เบอร์โทร</th>
     				<th scope="col">อีเมล</th>
      				<th scope="col">ประเภท</th>
	  				<th scope="col">BadmintonCourt</th>
	  				<th scope="col">TerminalGym</th>
	  				<th scope="col">TimeStart</th>
	  				<th scope="col">Timefinish</th>
	  				<th scope="col">BadmintonID</th>
    			</tr>
  			</thead></tr>
		 <tbody style="background-color: #EFEFEF">
<?php 

foreach($ReserveList as $Reserve)
{
	echo"<tr align='center' >
    <td data-lable='ชื่อผู้จอง'>$Reserve->ReserveName</td> 
    <td data-lable='เบอร์โทร'>$Reserve->ReserveTel</td>
    <td data-lable='อีเมล'>$Reserve->ReserveEmail</td>
    <td data-lable='ประเภท'>$Reserve->TypePerson</td>
    <td data-lable='BadmintonCourt'>$Reserve->BadmintonCourt</td> 
    <td data-lable='TerminalGym'>$Reserve->TerminalGym</td> 
    <td data-lable='TimeStart'>$Reserve->TimeStart</td> 
    <td data-lable='Timefinish'>$Reserve->TimeFinish</td> 
    <td data-lable='BadmintonID'>$Reserve->BadmintonID</td> </tr>"; 
    
}
echo "</table>";
?>
			 </tbody>
		</div>
	</body>

</html>	


