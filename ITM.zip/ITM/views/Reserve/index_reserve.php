<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>

	<body>
		<div class="container">
			<div><br></div>
			<table class="shadow table table-striped">
  			<thead class="thead-dark">
   				 <tr align='center' >
      				<th scope="col">ชื่อผู้จอง</th>
      				<th scope="col">เบอร์โทร</th>
     				<th scope="col">อีเมล</th>
      				<th scope="col">ประเภท</th>
	  				<th scope="col">BadmintonCourt</th>
	  				<th scope="col">TerminalGym</th>
	  				<th scope="col">TimeStart</th>
	  				<th scope="col">Timefinish</th>
	  				<th scope="col">BadmintonID</th>
    			</tr>
  			</thead></tr>
		 <tbody style="background-color: #EFEFEF">
<?php 

foreach($ReserveList as $Reserve)
{
	echo"<tr align='center' >
    <td data-lable='ชื่อผู้จอง'>$Reserve->ReserveName</td> 
    <td data-lable='เบอร์โทร'>$Reserve->ReserveTel</td>
    <td data-lable='อีเมล'>$Reserve->ReserveEmail</td>
    <td data-lable='ประเภท'>$Reserve->TypePerson</td>
    <td data-lable='BadmintonCourt'>$Reserve->BadmintonCourt</td> 
    <td data-lable='TerminalGym'>$Reserve->TerminalGym</td> 
    <td data-lable='TimeStart'>$Reserve->TimeStart</td> 
    <td data-lable='Timefinish'>$Reserve->TimeFinish</td> 
    <td data-lable='BadmintonID'>$Reserve->BadmintonID</td> </tr>"; 
    
}
echo "</table>";
?>
			 </tbody>
		</div>
	</body>

</html>	


