<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>

<body>
	<div class="py-5">
   		  <img class="d-block mx-auto" src="https://cdn.discordapp.com/attachments/611238647932518421/690917696161841192/logo.png" alt="" width="250">
</div>
	<div class="container">

	<div class="card shadow" style="width: 100%;
  max-width: 600px;
  padding: 15px;
  margin: auto;"> 
		 <h5 class="card-header">แบบฟอร์มการจอง</h5>
	  <div class="card-body">
		  <div class="mb-3">
					<form method="get" action="">
						<label>ชื่อผู้จอง </label>
<input type="text" class="form-control" name="ReserveName" /> 
							<div class="invalid-feedback">กรุณาใส่ชื่อผู้จอง</div>
       			 </div>
				<div class="mb-3">
					<form method="get" action="">
						<label>เบอร์โทร </label>
<input type="text" class="form-control" name="ReserveTel" />
							<div class="invalid-feedback" >กรุณาใส่เบอร์โทร</div>
       			 </div>
				<div class="mb-3">
       				   <label for="email">อีเมลล์ </label>
   				  <input type="email" class="form-control" name="ReserveEmail" placeholder="you@example.com" >
         			 	<div class="invalid-feedback">กรุณาใส่อีเมลล์</div>
						   
        		</div>
<div class="">
           			 <label>ประเภทบุคคล <select name="TypePerson" class="custom-select d-block w-100" id="country" ></label>
              			<?php echo "<option value=''>ตัวเลือก...</option>";
								echo "<option value='เด็กอายุต่ำกว่า13'>เด็กอายุต่ำกว่า13</option>";
								echo "<option value='นักเรียนและนิสิต'>นักเรียนและนิสิต</option>";
								echo "<option value='บุคลากร'>บุคลากร</option>";
								echo "<option value='บุคคลทั่วไป'>บุคคลทั่วไป</option>";
						?>
            		</select>
         	  		<div class="invalid-feedback">
            		  กรุณาเลือกประเภทบุคคล
           		 	</div>
          		</div>
<div class="row mb-3">
					<div class="col-sm">
           				 <label>ไอดีของสนาม</label>
           				 <input type="int" class="form-control" name="BadmintonID" readonly="true"
   						 value="<?php echo $BadmintonTable->BadmintonID;?>"/> 		
         			 </div>
					<div class="col-sm">
           				 <label>คอร์ดแบต</label>
           				 <input type="text" class="form-control" name="BadmintonCourt" readonly="true" 
   						 value="<?php echo $BadmintonTable->BadmintonCourt;?>"/> 		
         			 </div>
					<div class="col-sm">
           				 <label>อาคาร</label>
           				 <input type="text" class="form-control" name="TerminalGym" readonly="true" 
   						 value="<?php echo $BadmintonTable->TerminalGym;?>"/> 		
         			 </div>
					
				</div>
				<div class="row mb-3">
					<div class="col-sm">
       				  <label>เวลาเริ่ม</label>
           				 <input type="int" class="form-control" name="TimeStart" readonly="true"
   						 value="<?php echo $BadmintonTable->TimeStart;?>"/> 		
       			  </div>
					<div class="col-sm">
       				  <label>เวลาสิ้นสุด</label>
           				 <input type="text" class="form-control" name="TimeFinish" readonly="true" 
   						 value="<?php echo $BadmintonTable->TimeFinish;?>"/> 		
       			  </div>
					
				</div>
					
				<div class="row">
					<div class="col-sm">
           				 <input type="hidden" name="controller" value="Reserve"/> 		
       			  </div>
					<div class="col-sm">
                        <button class="btn btn-outline-danger btn-lg btn-block" type="submit" name="action" value="index">ยกเลิก</button>
                    </div>
					
					<div class="col-sm">
       				  <button class="btn btn-outline-success btn-lg btn-block" type="submit" name="action" value="addReserve"> ยืนยันการจอง</button> 		
       			  </div>
				</div>
		
	
	     </div>
</div></div></div></div>

<div><br></div>
	
</body>
</html>




