<html>

<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>

<body>
    <div class="py-5">
        <img class="d-block mx-auto" src="https://cdn.discordapp.com/attachments/611238647932518421/690917696161841192/logo.png" alt="" width="250">
    </div>
    <div class="container">

        <div class="card shadow" style="width: 100%;
  max-width: 600px;
  padding: 15px;
  margin: auto;">
            <h5 class="card-header">แบบฟอร์มการจอง</h5>
            <div class="card-body">
			<form method="get" action="" class="was-validated">
                <div class="mb-3">
                    
                        <label>ชื่อผู้จอง </label>
                        <input type="text" class="form-control " name="ReserveName" required/>
                        <div class="valid-feedback">Valid.</div>
      					<div class="invalid-feedback">กรุณาใส่ชื่อผู้จอง</div>
                </div>
                <div class="mb-3">
               
                        <label>เบอร์โทร </label>
                        <input type="text" class="form-control" name="ReserveTel" required/>
						<div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">กรุณาใส่เบอร์โทร</div>
                </div>
                <div class="mb-3">
                    <label for="email">อีเมลล์ </label>
                    <input type="email" class="form-control "id="myemail" name="ReserveEmail" placeholder="you@example.com" required>
					<div class="valid-feedback">Valid.</div>
                    <div class="invalid-feedback">กรุณาใส่อีเมลล์</div>

                </div>
                <div class="">
                    <label>ประเภทบุคคล
                        <select name="TypePerson" class="custom-select d-block w-100 " id="country" required>
                    </label>
                    <?php echo "<option value=''>ตัวเลือก...</option>";
								echo "<option value='เด็กอายุต่ำกว่า13'>เด็กอายุต่ำกว่า13</option>";
								echo "<option value='นักเรียนและนิสิต'>นักเรียนและนิสิต</option>";
								echo "<option value='บุคลากร'>บุคลากร</option>";
								echo "<option value='บุคคลทั่วไป'>บุคคลทั่วไป</option>";
						?>
                        </select>
						<div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">
                            กรุณาเลือกประเภทบุคคล
                        </div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm">
                        <label>ไอดีของสนาม</label>
                        <input type="int" class="form-control" name="BadmintonID" readonly="true" value="<?php echo $BadmintonTable->BadmintonID;?>" />
                    </div>
                    <div class="col-sm">
                        <label>คอร์ดแบต</label>
                        <input type="text" class="form-control" name="BadmintonCourt" readonly="true" value="<?php echo $BadmintonTable->BadmintonCourt;?>" />
                    </div>
                    <div class="col-sm">
                        <label>อาคาร</label>
                        <input type="text" class="form-control" name="TerminalGym" readonly="true" value="<?php echo $BadmintonTable->TerminalGym;?>" />
                    </div>

                </div>
                <div class="row mb-3">
                    <div class="col-sm">
                        <label>เวลาเริ่ม</label>
                        <input type="int" class="form-control" name="TimeStart" readonly="true" value="<?php echo $BadmintonTable->TimeStart;?>" />
                    </div>
                    <div class="col-sm">
                        <label>เวลาสิ้นสุด</label>
                        <input type="text" class="form-control" name="TimeFinish" readonly="true" value="<?php echo $BadmintonTable->TimeFinish;?>" />
                    </div>

                </div>

                <div class="row">
                    <div class="col-sm">
                        <input type="hidden" name="controller" value="Reserve" />
                    </div>
                    <div class="col-sm">

                        <a href="./?controller=BadmintonTable&action=index" class="btn btn-outline-danger btn-lg btn-block" role="button">ยกเลิก</a>
                    </div>

                    <div class="col-sm">
                        <button class="btn btn-outline-success btn-lg btn-block" type="submit" name="action" value="addReserve"> ยืนยันการจอง</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>
    </div>

    <div>
        <br>
    </div>

</body>

</html>