<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
		<div class="container">
			<div><br></div>
		<table class="shadow table table-striped">
  			<thead class="thead-dark">
    			<tr align='center' >
     			 <th scope="col">ลำดับ</th>
     			 <th scope="col">ประเภท</th>
    			 <th scope="col">TerminalGym</th>
    			 <th scope="col">ราคาสมาชิก/ปี</th>
		  		 <th scope="col">ราคาสมาชิก/ครั้ง</th>
	 			 <th scope="col">ราคาไม่ใช่สมาชิก/ครั้ง</th>
   			   </tr>
  			</thead></tr>
			<tbody style="background-color: #EFEFEF">
<?php foreach($RateBadmintonList as $RateBadminton)
{
	echo"<tr align='center' > 
	<td data-lable='ลำดับ'>$RateBadminton->RateBadmintonID</td>
	<td data-lable='ประเภท'>$RateBadminton->TypeRatePerson</td> 
	<td data-lable='TerminalGym'>$RateBadminton->TerminalGym</td>
	<td data-lable='ราคาสมาชิก/ปี'>$RateBadminton->PriceMemberPerYear</td> 
	<td data-lable='ราคาสมาชิก/ครั้ง'>$RateBadminton->PriceMember</td>
	<td data-lable='ราคาไม่ใช่สมาชิก/ครั้ง'>$RateBadminton->PriceNotMember</td> </tr>"; 
}
echo "</table>";
?>
				</tbody>
			</div>
	</body>

</html>
