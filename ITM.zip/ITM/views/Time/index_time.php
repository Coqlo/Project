<table border = 1>
<tr> <td>TimeID</td><td>TimeStart</td><td>TimeFinish</td></tr>
<?php foreach($TimeList as $Time)
{
	echo"<tr> <td>$Time->TimeID</td>
    <td>$Time->TimeStart</td>
     <td>$Time->TimeFinish</td></tr>"; 
}
echo "</table>";
?>
