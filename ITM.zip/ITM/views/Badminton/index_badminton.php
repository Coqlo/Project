<table border = 1>
<tr> <td>BadmintonID</td><td>BadmintonCourt</td><td>StatusCourt</td><td>BadmintonID</td><td>TimeID</td></tr>
<?php foreach($BadmintonList as $Badminton)
{
	echo"<tr> <td>$Badminton->BadmintonID</td>
    <td>$Badminton->BadmintonCourt</td>
    <td>$Badminton->StatusCourt</td>
    <td>$Badminton->GymID</td>
    <td>$Badminton->TimeID</td></tr>"; 
}
echo "</table>";
?>
