<table border = 1>
<tr> <td>GymID</td><td>GymName</td></tr>
<?php foreach($GymList as $Gym)
{
	echo"<tr> <td>$Gym->GymID</td>
    <td>$Gym->GymName</td></tr>"; 
}
echo "</table>";
?>
