<?php
$controllers=array('pages'=>['home','error'],'BadmintonTable'=>['index','search'],'RateBadminton'=>['index','newRateBadminton','addRateBadminton','search','update','updateForm','deleteConfirm','delete'],'Reserve'=>['index','newReserve','addReserve','deleteConfirm','delete','search'],
'Time'=>['index','newTime','addTime','search','updateForm','update','deleteConfirm','delete'],'Gym'=>['index','newGym', 'addGym','search','updateForm','update','deleteConfirm','delete'],
'Badminton'=>['index','newBadminton','addBadminton','search','updateForm','update','deleteConfirm','delete','updateColumn'],
'MemberBadminton'=>['index','newMemberBadminton','addMemberBadminton','search','updateForm','update','deleteConfirm','delete'],
'HistoryReserve'=>['index','search','newHistoryReserve','addHistoryReserve']);

function call($controller,$action){
	require_once("controllers/".$controller."_Controller.php");
	switch($controller)
	{
		case "pages"		: 	$controller = new PagesController();
					  			break;
		case "BadmintonTable"	: require_once("models/BadmintonTableModel.php");
								$controller = new BadmintonTableController();
								break;
		case "RateBadminton" :	require_once("models/RateBadmintonModel.php");
								$controller = new RateBadmintonController();
								break;
		case "Reserve"		:	require_once("models/ReserveModel.php");
								require_once("models/TimeModel.php");
								require_once("models/BadmintonModel.php");
								$controller = new ReserveController();
								break;
		case "Time"			:	require_once("models/TimeModel.php");
								$controller = new TimeController();
								break;
		case "Gym" 			:	require_once("models/GymModel.php");
								$controller = new GymController();
								break;
		case "Badminton"	:	require_once("models/BadmintonModel.php");
								require_once("models/TimeModel.php");
								require_once("models/GymModel.php");
								$controller = new BadmintonController();
								break;
		case "MemberBadminton" : require_once("models/MemberBadmintonModel.php");
								 $controller = new MemberBadmintonController();
								break;
		case "HistoryReserve"	: require_once("models/HistoryReserveModel.php");
								 require_once("models/ReserveModel.php");
								 require_once("models/BadmintonModel.php");
								 $controller = new HistoryReserveController();
								break;
		
		
								
	}
	$controller->{$action}();
}

if(array_key_exists($controller,$controllers))
{
	if(in_array($action,$controllers[$controller]))
	{
		call($controller,$action);
	}
	else
		call('pages','error');
}
else{
	call('pages','error');	
}
?>