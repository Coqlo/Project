<?php class StatOfDayController
{
	public function index()
	{
		$StatOfDayList=StatOfDay::getAll();
		require_once('views/StatOfDay/index_statofday.php');
	}
	public function newStatOfDay()
	{
		$StatOfDayList=StatOfDay::getAll();
		require_once('views/StatOfDay/newStatOfDay.php');
	}
	public function addStatOfDay()
	{
		$StatOfDayID=$_GET['StatOfDayID'];
		$StatOfDayName=$_GET['StatOfDayName'];

		StatOfDay::Add($StatOfDayID,$StatOfDayName);
		StatOfDayController::index();

	}

	public function search()
	{
		$key=$_GET['key'];
		$StatOfDayList=StatOfDay::search($key);
		require_once('views/StatOfDay/index_statofday.php');
	}
	public function updateForm()
	{
		$StatOfDayID=$_GET['StatOfDayID'];
		$StatOfDay=StatOfDay::get($StatOfDayID);
		$StatOfDayList=StatOfDay::getAll();
		require_once('views/StatOfDay/updateForm.php');
	}
	public function update()
	{
		$StatOfDayID=$_GET['StatOfDayID'];
		$StatOfDayName=$_GET['StatOfDayName'];

		StatOfDay::update($StatOfDayID,$StatOfDayName);
		StatOfDayController::index();
	}
	public function deleteConfirm()
	{
		$StatOfDayID=$_GET['StatOfDayID'];
		$StatOfDay=StatOfDay::get($StatOfDayID);
		require_once('views/StatOfDay/deleteConfirm.php');
	}
	public function delete()
	{
			$StatOfDayID=$_GET['StatOfDayID'];
			StatOfDay::delete($StatOfDayID);
			StatOfDayController::index();
	}



}?>