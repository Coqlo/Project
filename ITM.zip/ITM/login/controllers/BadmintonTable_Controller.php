<?php class BadmintonTableController
{
	public function index(){
		$BadmintonTableList = BadmintonTable::getAll();
		require_once('views/BadmintonTable/index_badmintontable.php');
	}
}?>