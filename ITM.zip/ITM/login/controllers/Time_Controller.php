<?php class TimeController
{
	public function index()
	{
		$TimeList=Time::getAll();
		require_once('views/Time/index_time.php');
	}

	public function newTime()
	{
		$TimeList=Time::getAll();
		require_once('views/Time/newTime.php');
	}

	public function addTime()
	{
		$TimeID=$_GET['TimeID'];
		$TimeStart=$_GET['TimeStart'];
		$TimeFinish=$_GET['TimeFinish'];

		Time::Add($TimeID,$TimeStart,$TimeFinish);
		TimeController::index();
	}

	public function search()
	{
		$key=$_GET['key'];
		$TimeList=Time::search($key);
		require_once('views/Time/index_time.php');
	}

	public function updateForm()
	{
		$TimeID=$_GET['TimeID'];
		$Time=Time::get($TimeID);
		$TimeList=Time::getAll();
		require_once('views/Time/updateForm.php');
	}

	public function update()
	{
		$TimeID=$_GET['TimeID'];
		$TimeStart=$_GET['TimeStart'];
		$TimeFinish=$_GET['TimeFinish'];

		Time::update($TimeID,$TimeStart,$TimeFinish);
		TimeController::index();
	}

	public function deleteConfirm()
	{
		$TimeID=$_GET['TimeID'];
		$Time=Time::get($TimeID);
		require_once('views/Time/deleteConfirm.php');
	}
	
	public function delete()
	{
			$TimeID=$_GET['TimeID'];
			Time::delete($TimeID);
			TimeController::index();
	}

	
}?>