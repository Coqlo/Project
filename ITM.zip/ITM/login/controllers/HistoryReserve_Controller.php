<?php 
class HistoryReserveController
{	
	public function index()
	{	$HistoryReserveList= HistoryReserve::getAll();
		require_once('views/HistoryReserve/index_historyreserve.php');
	}
	public function search()
	{
        $key=$_GET['key'];
        $HistoryReserveList=HistoryReserve::search($key);
        require_once('views/HistoryReserve/index_historyreserve.php');
	}
	
	public function newHistoryReserve()
	{	
		$id=$_GET['ReserveID'];
		$Reserve = Reserve::get($id);
		$BadmintonList=Badminton::getAll();
		$ReserveList=Reserve::getAll();
		require_once("views/HistoryReserve/newHistoryReserve.php");
		
	}

	public function addHistoryReserve()
	{
		$ReserveName=$_GET['ReserveName'];
		$ReserveTel=$_GET['ReserveTel'];
		$ReserveEmail=$_GET['ReserveEmail'];
		$TypePerson = $_GET['TypePerson'];
		$NotOrMember=$_GET['NotOrMember'];
		$Price=$_GET['Price'];
		$BadmintonID=$_GET['BadmintonID'];
		$ReserveDate=$_GET['ReserveDate'];
		
		HistoryReserve::Add($ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$NotOrMember,$Price,$BadmintonID,$ReserveDate);
		HistoryReserveController::index();
	
	}

    
}?>