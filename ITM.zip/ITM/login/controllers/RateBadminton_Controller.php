<?php 
class RateBadmintonController
{
	public function index()
	{
		$RateBadmintonList=RateBadminton::getAll();
		require_once('views/RateBadminton/index_ratebadminton.php');
	}

	public function newRateBadminton()
	{
		$RateBadmintonList=RateBadminton::getAll();
		require_once('views/RateBadminton/newRateBadminton.php');

	}

	public function addRateBadminton()
	{
		$RateBadmintonID=$_GET['RateBadmintonID'];
		$TypeRatePerson=$_GET['TypeRatePerson'];
		$TerminalGym=$_GET['TerminalGym'];
		$PriceMemberPerYear=$_GET['PriceMemberPerYear'];
		$PriceMember=$_GET['PriceMember'];
		$PriceNotMember=$_GET['PriceNotMember'];
		RateBadminton::Add($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember);
		RateBadmintonController::index();
	}

	public function search()
	{
		$key=$_GET['key'];
		$RateBadmintonList=RateBadminton::search($key);
		require_once('views/Ratebadminton/index_ratebadminton.php');
	}

	public function update()
	{
		//error_reporting(~E_NOTICE);
		$RateBadmintonID=$_GET['RateBadmintonID'];
		$TypeRatePerson=$_GET['TypeRatePerson'];
		$TerminalGym=$_GET['TerminalGym'];
		$PriceMemberPerYear=$_GET['PriceMemberPerYear'];
		$PriceMember=$_GET['PriceMember'];
		$PriceNotMember=$_GET['PriceNotMember'];
		RateBadminton::update($RateBadmintonID,$TypeRatePerson, $TerminalGym, $PriceMemberPerYear, $PriceMember ,$PriceNotMember);
		RateBadmintonController::index();
	}

	public function updateForm()
	{
		$RateBadmintonID=$_GET['RateBadmintonID'];
		$RateBadminton = RateBadminton::get($RateBadmintonID);
		$RateBadmintonList=RateBadminton::getAll();
		require_once('views/RateBadminton/updateForm.php');
	}

	public function deleteConfirm()
	{
		$RateBadmintonID=$_GET['RateBadmintonID'];
		$RateBadminton=RateBadminton::get($RateBadmintonID);
		require_once('views/RateBadminton/deleteConfirm.php');

	}

	public function delete()
	{
		
		$RateBadmintonID=$_GET['RateBadmintonID'];
		RateBadminton::delete($RateBadmintonID);
		RateBadmintonController::index();
	}

}?>