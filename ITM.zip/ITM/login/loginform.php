<html>
	<head>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</head>
	<style>
body  {
	width:100%;
  background-image: url("https://cdn.discordapp.com/attachments/611238647932518421/691300390582485062/bg.jpg") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
}
</style>
	
	<body style="display: -ms-flexbox;
  			display: flex;
  			-ms-flex-align: center;
 			 align-items: center;
 			 padding-top: 50px;
 			 padding-bottom: 50px;">
		  	
	
<?php session_start();?>
<?php
require_once('h.php');
?>

<style type="text/css">
#btn{
width:100%;
}

</style>
		
		  	
<form class="formlogin" action="checklogin.php" method="POST" id="login" class="form-horizontal" style="
  margin: auto;
  background-color: #EBEBEB;">
	<img class="rounded" src="https://cdn.discordapp.com/attachments/611238647932518421/690917696161841192/logo.png" alt="" width="304" height="190" >	

  <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
  <label for="inputEmail" class="sr-only">Email address</label>
  <input type="text"  name="username" class="form-control" required placeholder="Username" />
  <label for="inputPassword" class="sr-only">Password</label>
  <input type="password" name="password" class="form-control" required placeholder="Password" />
    
  <div class="checkbox mb-3">
    <label>
      <input type="checkbox" checked="checked" name="remember" style="font-weight: 400;"> Remember me
    </label>
  </div>
  <button class="btn btn-lg btn-primary btn-block" type="submit"	>Sign in</button>
</form>


	<br>

</body>	
    



</html>	
