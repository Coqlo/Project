
<?php class StatOfDay{
	public $ReserveDate,$Price;
	public function StatOfDay($ReserveDate,$Price)
	{
		$this->ReserveDate = $ReserveDate;
		$this->Price = $Price;
		
	}
	public static function getAll()
	{
		$StatOfDayList=[];
		require("connection_connect.php");
		$sql="select * from StatOfDay";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$ReserveDate=$my_row['ReserveDate'];
			$Price=$my_row['Price'];
			
			$StatOfDayList[]=new StatOfDay($ReserveDate,$Price);
		}
		require("connection_close.php");
		return $StatOfDayList;
			
	}
	public static function add($ReserveDate,$Price)
	{
		require("connection_connect.php");
		$sql="insert into StatOfDay (ReserveDate,Price)
		values('$ReserveDate','$Price')";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "add success $result rows";
	}
	

	public static function search($key)
	{
		$StatOfDayList=[];
		require("connection_connect.php");
		$sql="select *from StatOfDay where (ReserveDate like'%$key%' or Price like'%$key%' )";
		$result=$conn->query($sql);
		while($my_row=$result->fetch_assoc())
		{
			$ReserveDate=$my_row['ReserveDate'];
			$Price=$my_row['Price'];
			
			$StatOfDayList[]=new StatOfDay($ReserveDate,$Price);	
		}
		require("connection_close.php");
		return $StatOfDayList;
	}
	public static function update($ReserveDate,$Price)
	{
	
		require("connection_connect.php");
		$sql="UPDATE StatOfDay SET Price = '$Price' WHERE ReserveDate = '$ReserveDate'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "update success $result row";
	}

	public static function get($id)
	{
		require("connection_connect.php");
		$sql="select *from StatOfDay where ReserveDate='$id'";;
		$result=$conn->query($sql);
		$my_row=$result->fetch_assoc();
		$id=$my_row['ReserveDate'];
		$Price=$my_row['Price'];
	
		require("connection_close.php");

		return new StatOfDay($id,$Price);
	}
	public static function delete($id)
	{
		require("connection_connect.php");
		$sql="Delete from StatOfDay	 where ReserveDate='$id'";
		$result=$conn->query($sql);
		require("connection_close.php");
		return "delete success $result row";
	}

}?>