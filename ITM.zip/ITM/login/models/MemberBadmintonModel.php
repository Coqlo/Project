<?php
Class MemberBadminton{
Public $MemberBadmintonID;
Public $MemberName;
Public $MemberAddress;
Public $MemberTel;
Public $MemberEmail;
Public $TypeMember;

Public function MemberBadminton($MemberBadmintonID,$MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember)
{            
           $this->MemberBadmintonID = $MemberBadmintonID;
           $this->MemberName = $MemberName;
           $this->MemberAddress = $MemberAddress;
           $this->MemberTel= $MemberTel;
           $this->MemberEmail = $MemberEmail;
           $this->TypeMember = $TypeMember;
}
public static function getAll()
{
	$MemberBadmintonList=[];
	require("connection_connect.php");
	$sql = "select * from MemberBadminton";
	$result = $conn->query($sql);
	
	while ($my_row=$result->fetch_assoc())
		{

			$MemberBadmintonID=$my_row['MemberBadmintonID'];
			$MemberName=$my_row['MemberName'];
			$MemberAddress=$my_row['MemberAddress'];
			$MemberTel=$my_row['MemberTel'];
			$MemberEmail=$my_row['MemberEmail'];
			$TypeMember=$my_row['TypeMember'];
			$MemberBadmintonList[]=new MemberBadminton($MemberBadmintonID,$MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember);
		}
		require("connection_close.php");
		return $MemberBadmintonList;
}

public static function add($MemberBadmintonID,$MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember)
{
	require("connection_connect.php");
	$sql="insert into MemberBadminton(MemberBadmintonID,MemberName, MemberAddress, MemberTel, MemberEmail ,TypeMember)
	values('$MemberBadmintonID','$MemberName', '$MemberAddress', '$MemberTel', '$MemberEmail' ,'$TypeMember')";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "add success $result rows";
}

public static function search($key)
{
	$MemberBadmintonList=[];
	require("connection_connect.php");
	$sql="select *from MemberBadminton where(MemberBadmintonID like'%$key%' or MemberName like'%$key%' or
	MemberAddress like'%$key%' or MemberTel like'%$key%' or MemberEmail like'%$key%' or TypeMember like'%$key%')";
	$result=$conn->query($sql);
	while($my_row=$result->fetch_assoc())
	{
		$MemberBadmintonID=$my_row['MemberBadmintonID'];
		$MemberName=$my_row['MemberName'];
		$MemberAddress=$my_row['MemberAddress'];
		$MemberTel=$my_row['MemberTel'];
		$MemberEmail=$my_row['MemberEmail'];
		$TypeMember=$my_row['TypeMember'];
		$MemberBadmintonList[]=new MemberBadminton($MemberBadmintonID,$MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember);
	}
	require("connection_close.php");
	return $MemberBadmintonList;
}

public static function update($MemberBadmintonID,$MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember)
{
	require("connection_connect.php");
	$sql="UPDATE MemberBadminton SET MemberName = '$MemberName', MemberAddress = '$MemberAddress', MemberTel = '$MemberTel',MemberEmail = '$MemberEmail', TypeMember = '$MemberEmail', TypeMember = '$TypeMember' WHERE MemberBadmintonID = '$MemberBadmintonID'";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "update success $result row";
}

public static function get($id)
{
	require("connection_connect.php");
	$sql="select *from MemberBadminton where MemberBadmintonID='$id'";;
	$result=$conn->query($sql);
	$my_row=$result->fetch_assoc();
	$id=$my_row['MemberBadmintonID'];
	$MemberName=$my_row['MemberName'];
	$MemberAddress=$my_row['MemberAddress'];
	$MemberTel=$my_row['MemberTel'];
	$MemberEmail=$my_row['MemberEmail'];
	$TypeMember=$my_row['TypeMember'];
	require("connection_close.php");

	return new MemberBadminton($id, $MemberName, $MemberAddress, $MemberTel, $MemberEmail ,$TypeMember);
}

public static function delete($id)
{
	require("connection_connect.php");
	$sql="Delete from MemberBadminton where MemberBadmintonID='$id'";
	$result=$conn->query($sql);
	require("connection_close.php");
	return "delete success $result row";
}
}?>