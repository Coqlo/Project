<?php 
class HistoryReserve{
	public $HistoryReserveID;
	public $ReserveName;
	public $ReserveTel;
  public $ReserveEmail;
  public $TypePerson;
  public $NotOrMember;
  public $Price;
	public $BadmintonID;
	public $ReserveDate;

public function HistoryReserve($HistoryReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$NotOrMember,$Price,$BadmintonID,$ReserveDate)
{
	
	$this->HistoryReserveID = $HistoryReserveID;
  $this->ReserveName = $ReserveName;
	$this->ReserveTel = $ReserveTel;
  $this->ReserveEmail = $ReserveEmail;
  $this->TypePerson = $TypePerson;
  $this->NotOrMember = $NotOrMember;
  $this->Price = $Price;
	$this->BadmintonID = $BadmintonID;
	$this->ReserveDate = $ReserveDate;
}


/*public static function get($ID)
{
  require("connection_connect.php");
  $sql = "select HistoryReserve.HistoryReserveID, HistoryReserve.ReserveName, HistoryReserve.ReserveTel, HistoryReserve.ReserveEmail,
  HistoryReserve.TimeID,HistoryReserve.BadmintonID,HistoryReserve.ReserveDate,HistoryReserve.ReserveRate
  *from HistoryReserve,Reserve,Badminton,Time 
  where HistoryReserveID='$ID' AND HistoryReserve.ReserveName=Reserve.ReserveName AND HistoryReserve.ReserveTel=Reserve.ReserveTel 
  AND HistoryReserve.ReserveEamil=Reserve.ReserveEmail AND HistoryReserve.TimeID=Time.TimeID AND HistoryReserve.BadmintonID=Badminton.BadmintonID";
  $result=$conn->query($sql);
  $my_row = $result->fetch_assoc();
  $HistoryReserveID=$my_row['HistoryReserveID'];
  $ReserveName=$my_row['ReserveName'];
  $ReserveTel=$my_row['ReserveTel'];
  $ResreveEmail=$my_row['ReserveEmail'];
  $TimeID=$my_row['TimeID'];
  $BadmintonID=$my_row['BadmintonID'];
  $ReserveDate=$my_row['ReserveDate'];

  require("connection_close.php");

  return new HistoryReserve($HistoryReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TimeID,$BadmintonID,$ReserveDate,$ReserveRate);
}*/

public static function getAll()
{
  $HistoryReserveList=[];
  require("connection_connect.php");
  $sql = "SELECT *FROM HistoryReserve";
  $result=$conn->query($sql);
  while($my_row = $result->fetch_assoc()){
    $HistoryReserveID=$my_row['HistoryReserveID'];
    $ReserveName=$my_row['ReserveName'];
    $ReserveTel=$my_row['ReserveTel'];
    $ReserveEmail=$my_row['ReserveEmail'];
    $TypePerson=$my_row['TypePerson'];
    $NotOrMember=$my_row['NotOrMember'];
    $Price=$my_row['Price'];
    $BadmintonID=$my_row['BadmintonID'];
    $ReserveDate=$my_row['ReserveDate'];
    
    $HistoryReserveList[]= new HistoryReserve($HistoryReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$NotOrMember,$Price,$BadmintonID,$ReserveDate);
}
require("connection_close.php");
return $HistoryReserveList;
}

public static function search($key)
{
	$HistoryReserveList=[];
	require("connection_connect.php");
	$sql="select *from HistoryReserve where(HistoryReserveID like'%$key%' or ReserveName like'%$key%' or
	ReserveTel like'%$key%' or ReserveEmail like'%$key%' or TypePerson like'%$key%' or NotOrMember like'%$key%' or Price like'%$key%' or BadmintonID like'%$key%' or ReserveDate like'%$key%')";
	$result=$conn->query($sql);
	while($my_row=$result->fetch_assoc())
	{
    $HistoryReserveID=$my_row['HistoryReserveID'];
    $ReserveName=$my_row['ReserveName'];
    $ReserveTel=$my_row['ReserveTel'];
    $ReserveEmail=$my_row['ReserveEmail'];
    $TypePerson=$my_row['TypePerson'];
    $NotOrMember=$my_row['NotOrMember'];
    $Price=$my_row['Price'];
    $BadmintonID=$my_row['BadmintonID'];
    $ReserveDate=$my_row['ReserveDate'];
    
    $HistoryReserveList[]= new HistoryReserve($HistoryReserveID,$ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$NotOrMember,$Price,$BadmintonID,$ReserveDate);
	}
	require("connection_close.php");
	return $HistoryReserveList;
}
public static function add($ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$NotOrMember,$Price,$BadmintonID,$ReserveDate)
{	require("connection_connect.php");
    $sql = "insert into HistoryReserve(ReserveName,ReserveTel,ReserveEmail,TypePerson,NotOrMember,Price,BadmintonID,ReserveDate)
    values ('$ReserveName','$ReserveTel','$ReserveEmail','$TypePerson','$NotOrMember','$Price','$BadmintonID','$ReserveDate')";
    $result=$conn->query($sql);
    $sql = "UPDATE Badminton SET StatusCourt='กำลังใช้งาน' where BadmintonID='$BadmintonID'";
    $result=$conn->query($sql);
    $sql = "DELETE from Reserve WHERE BadmintonID='$BadmintonID'";
    $result=$conn->query($sql);
   
   
	require("connection_close.php");
	return "add success $result rows";}

}