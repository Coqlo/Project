<?php echo "<br>Are you sure to delete this Badminton <br>
            <br>$Badminton->BadmintonID $Badminton->BadmintonCourt $Badminton->StatusCourt $Badminton->GymID $Badminton->TimeID<br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="Badminton"/>
    <input type="hidden" name="BadmintonID" value="<?php echo $Badminton->BadmintonID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>