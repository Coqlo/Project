<form method = "get" action="">
    <label>BadmintonID<input type="int" name="BadmintonID"
        value="<?php echo $Badminton->BadmintonID; ?>" /> </label><br>
     <label>BadmintonCourt<input type="text" name="BadmintonCourt"
        value="<?php echo $Badminton->BadmintonCourt; ?>" /> </label><br>
    <label>StatusCourt<select  name="StatusCourt">
          <?php echo "<option value=''></option>";
          echo "<option value='ว่าง'>ว่าง</option>";
          echo "<option value='กำลังใช้งาน'>กำลังใช้งาน</option>";
          echo "<option value='จองแล้ว'>จองแล้ว</option>";
    ?>
							 </select></label><br>

    <label>GymID <select name="GymID">
            <?php foreach($GymList as $Gym){
                echo "<option value=$Gym->GymID";
                echo ">$Gym->GymName</option>";
            } ?>
    </select></label><br>

    <label>TimeID <select name="TimeID">
            <?php foreach($TimeList as $Time){
                echo "<option value=$Time->TimeID";
                echo ">$Time->TimeStart-$Time->TimeFinish</option>";
            } ?>
    </select></label><br>
       
    

<input type="hidden" name="controller" value="Badminton"/>
<button type="submit" name="action" value="index">Back</button>
<button type="submit" name="action" value="update">update</button>
</form>