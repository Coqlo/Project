<!--<table border = 1>
<tr> <td>BadmintonID</td><td>BadmintonCourt</td><td>StatusCourt</td><td>GymID</td><td>BadmintonID</td><td>Update</td><td>Delete</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="Badminton"/>
	<button type="submit" name="action" value="search">
Search</button>

<?php foreach($BadmintonList as $Badminton)
{
	echo"<tr> 
	<td>$Badminton->BadmintonID</td>
    <td>$Badminton->BadmintonCourt</td>
    <td>$Badminton->StatusCourt</td>
    <td>$Badminton->GymID</td>
    <td>$Badminton->BadmintonID</td>
    <td><a href=?controller=Badminton&action=updateForm&BadmintonID=$Badminton->BadmintonID>update</td>
    <td><a href=?controller=Badminton&action=deleteConfirm&BadmintonID=$Badminton->BadmintonID>delete</td></tr>"; 
}
echo "</table>";
?>
<html>
<head></head>
<body>
        [<a href=?controller=Badminton&action=newBadminton> click </a>]
        [<a href=?controller=Badminton&action=updateColumn> ล้างสถานะการจองทั้งหมวด</a>]
</body>
</html>-->

<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
		<div class="container">
			<div><br></div>
			<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Badminton" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="Badminton" class="form-control" placeholder="ค้นหา" aria-label="Badminton" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
						
						<a href=./?controller=Badminton&action=newBadminton type="button" class="btn btn-primary">เพิ่มคอร์ด</a>
                        <a href=./?controller=Badminton&action=updateColumn type="button" class="btn btn-primary">ล้างสถานะการจองทั้งหมวด</a>
					
					</div>
				</form>
                <div class=" shadow div2" >
		<table class="shadow table table-hover">
  			<thead class="thead-dark">
    			<tr align='center' >
     			 <th scope="col">BadmintonID</th>
     			 <th scope="col">BadmintonCourt</th>
    			 <th scope="col">StatusCourt</th>
                 <th scope="col">GymID</th>
                 <th scope="col">BadmintonID</th>
				 <th scope="col">อัพเดท</th>
				 <th scope="col">ลบ</th>
   			   </tr>
  			</thead></tr>
			<tbody style="background-color: #EFEFEF">
<?php foreach($BadmintonList as $Badminton)
{
    echo"<tr align='center' > 
    <td data-lable='BadmintonID'>$Badminton->BadmintonID</td>
    <td data-lable='BadmintonCourt'>$Badminton->BadmintonCourt</td>";
    if ($Badminton->StatusCourt == "ว่าง")
	{
		echo "<td data-lable='สถานะ' role='button'  class='btn btn-success' aria-disabled='true' >$Badminton->StatusCourt</td>";
	}
	if ($Badminton->StatusCourt == "จองแล้ว")
	{
		echo "<td data-lable='สถานะ' role='button' class='btn btn-danger' aria-disabled='true' >$Badminton->StatusCourt</td>";
	}
	if ($Badminton->StatusCourt == "กำลังใช้งาน")
	{
		echo "<td data-lable='สถานะ' class='btn btn-warning' role='button' aria-disabled='true' >$Badminton->StatusCourt</td>";
	}
    echo "<td data-lable='GymID'>$Badminton->GymID</td>
        <td data-lable='BadmintonID'>$Badminton->BadmintonID</td>
        <td data-lable='อัพเดท'><a href=?controller=Badminton&action=updateForm&BadmintonID=$Badminton->BadmintonID class='btn btn-outline-warning' role='button' ata-placement='right' title='อัพเดทเวลา'>updete</a></td>
        <td data-lable='ลบ'><a href=?controller=Badminton&action=deleteConfirm&BadmintonID=$Badminton->BadmintonID class='btn btn-outline-danger' role='button' ata-placement='right' title='ลบเวลา'>delete</a></td><tr>";
				
	echo "</table>";
				?>
				</tbody>
			</div>
	</body>
</html>
