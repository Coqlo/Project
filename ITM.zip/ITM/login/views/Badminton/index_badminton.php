
<html>
 <head>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
 </head>
 
 <body>
  <div class="container">
   <div><br></div>
   <form method="get" action="">
     <div class=" shadow input-group mb-3 " >
      <input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Badminton" aria-describedby="button-addon2">
      <input type="hidden" name="controller" value="Badminton" class="form-control" placeholder="ค้นหา" aria-label="Badminton" aria-describedby="button-addon2">
      <div class=" input-group-append ">
       <button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2"><i class="fas fa-search"></i> Search</button>
      </div>
      
      <a href="./?controller=Badminton&action=newBadminton" type=button  class="btn btn-primary"><i class="fas fa-folder-plus"></i> เพิ่มคอร์ด</a>
                        <a href="./?controller=Badminton&action=updateColumn" type=button class="btn btn-info"><i class="fas fa-redo-alt"></i> ล้างสถานะการจองทั้งหมวด</a>
     
     </div>
    </form>
                <div class=" shadow div2" >
  <table class="shadow table table-hover">
     <thead class="thead-dark">
       <tr align='center' >
         <th scope="col">BadmintonID</th>
         <th scope="col">BadmintonCourt</th>
        <th scope="col">StatusCourt</th>
                 <th scope="col">GymID</th>
                 <th scope="col">BadmintonID</th>
     <th scope="col">อัพเดท</th>
     <th scope="col">ลบ</th>
         </tr>
     </thead></tr>
   <tbody style="background-color: #EFEFEF">
<?php foreach($BadmintonList as $Badminton)
{
    echo"<tr align='center' > 
    <td data-lable='BadmintonID'>$Badminton->BadmintonID</td>
    <td data-lable='BadmintonCourt'>$Badminton->BadmintonCourt</td>";
    if ($Badminton->StatusCourt == "ว่าง")
 {
  echo "<td data-lable='StatusCourt' role='button'  class='btn btn-success' aria-disabled='true' >$Badminton->StatusCourt</td>";
 }
 if ($Badminton->StatusCourt == "จองแล้ว")
 {
  echo "<td data-lable='StatusCourt' role='button' class='btn btn-danger' aria-disabled='true' >$Badminton->StatusCourt</td>";
 }
 if ($Badminton->StatusCourt == "กำลังใช้งาน")
 {
  echo "<td data-lable='StatusCourt' class='btn btn-warning' role='button' aria-disabled='true' >$Badminton->StatusCourt</td>";
 }
    echo "<td data-lable='GymID'>$Badminton->GymID</td>
        <td data-lable='BadmintonID'>$Badminton->BadmintonID</td>
        <td data-lable='อัพเดท'><a href=?controller=Badminton&action=updateForm&BadmintonID=$Badminton->BadmintonID class='btn btn-outline-warning' role='button' ata-placement='right' title='อัพคอร์ด'><i class='fas fa-folder-open'></i> updete</a></td>
        <td data-lable='ลบ'><a href=?controller=Badminton&action=deleteConfirm&BadmintonID=$Badminton->BadmintonID class='btn btn-outline-danger' role='button' ata-placement='right' title='ลบเวลา'><i class='fas fa-folder-minus'></i> delete</a></td><tr>";
}   
 echo "</table>";
    ?>
    </tbody>
   </div>
 </body>
</html>
