<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>
    <style>
body  {
	width:100%;
  background-image: url("https://cdn.discordapp.com/attachments/611238647932518421/690914863048032306/logo.jpg") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
	background-position: center;
}
</style>
	
	<body>
		<div class="container">
			<div><br></div>
			<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Time" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="Time" class="form-control" placeholder="ค้นหา" aria-label="Time" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
						
						<a href=./?controller=Time&action=newTime type="button" class="btn btn-primary">เพิ่มเวลา</a>
					
					</div>
				</form>
		<table class="shadow table table-hover">
  			<thead class="thead-dark">
    			<tr align='center' >
     			 <th scope="col">TimeID</th>
     			 <th scope="col">TimeStart</th>
    			 <th scope="col">TimeFinish</th>
				 <th scope="col">อัพเดท</th>
				 <th scope="col">ลบ</th>
   			   </tr>
  			</thead></tr>
			<tbody style="background-color: #EFEFEF">
<?php foreach($TimeList as $Time)
{
    echo"<tr align='center' > 
    <td data-lable='TimeID'>$Time->TimeID</td>
	<td data-lable='TimeStart'>$Time->TimeStart</td>
	<td data-lable='TimeFinish'>$Time->TimeFinish</td>
	<td data-lable='อัพเดท'><a href=?controller=Time&action=updateForm&TimeID=$Time->TimeID class='btn btn-outline-warning' role='button' ata-placement='right' title='อัพเดทเวลา'>updete</a></td>
	<td data-lable='ลบ'><a href=?controller=Time&action=deleteConfirm&TimeID=$Time->TimeID class='btn btn-outline-danger' role='button' ata-placement='right' title='ลบเวลา'>delete</a></td><tr>";
}
echo "</table>";
?>
				</tbody>
			</div>
	</body>

</html>
