<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>
	<style>
body  {
	width:100%;
  background-image: url("https://cdn.discordapp.com/attachments/611238647932518421/690914863048032306/logo.jpg") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
	background-position: center;
}
</style>
	<body >
		<div class="container">
			<div><br></div>
				<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="HistoryReserve" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="HistoryReserve" class="form-control" placeholder="ค้นหา" aria-label="HistoryReserve" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
					
					</div>
				</form>
			
		<div class=" shadow div table-responsive" >
			<table class="table table-bordered table-striped table-condensed">
  				<thead class="thead-dark">
		  		  <tr align="center">
      				<th scope="col">HistoryReserveID</th>
     				<th scope="col">ReserveName</th>
    				<th scope="col">ReserveTel</th>
      				<th scope="col">ReserveEmail</th>
	  				<th scope="col">TypePerson</th>
	  				<th scope="col">NotOrMember</th>
					<th scope="col">Price</th>
					  <th scope="col">BadmintonID</th>
					  <th scope="col">DateReserve</th>
   				</tr>
  				</thead>
				<tbody style="background-color: #EFEFEF">
		
<?php 
foreach($HistoryReserveList as $HistoryReserve)
{
    echo"<tr align='center' >
	<td data-lable='HistoryReserveID'>$HistoryReserve->HistoryReserveID</td>
    <td data-lable='ReserveName'>$HistoryReserve->ReserveName</td> 
    <td data-lable='ReserveTel'>$HistoryReserve->ReserveTel</td>
    <td data-lable='ReserveEmail'>$HistoryReserve->ReserveEmail</td> 
    <td data-lable='TypePerson'>$HistoryReserve->TypePerson</td> 
    <td data-lable='NotOrMember'>$HistoryReserve->NotOrMember</td> 
    <td data-lable='Price'>$HistoryReserve->Price</td> 
    <td data-lable='BadmintonID'>$HistoryReserve->BadmintonID</td>
	<td data-lable='DateReserve'>$HistoryReserve->ReserveDate</td></tr>"; 
    
}
echo "</table>";
?>

					</tbody>
			</div>
	</body>
</html>


	


