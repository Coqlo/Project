
<html>

<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>

<body>
    <div class="py-5">
        <img class="d-block mx-auto" src="https://cdn.discordapp.com/attachments/611238647932518421/690917696161841192/logo.png" alt="" width="250">
    </div>
    <div class="container">

        <div class="card shadow" style="width: 100%;
  max-width: 600px;
  padding: 15px;
  margin: auto;">
            <h5 class="card-header">อนุมัติรายการจอง</h5>
            <div class="card-body">
                <div class="mb-3">
                    <form method="get" action="">
                    <label>ชื่อผู้จอง </label> <input type="text" name="ReserveName" readonly="true" 
    value="<?php echo $Reserve->ReserveName;?>" class="form-control" required/>   
                </div>
                <div class="mb-3">
                    <form method="get" action="">
                    <label>เบอร์โทร </label> <input type="text" name="ReserveTel"readonly="true" 
    value="<?php echo $Reserve->ReserveTel;?>" class="form-control" required/>
                </div>
                <div class="mb-3">
                <label>อีเมลล์ </label><input type="text" name="ReserveEmail" readonly="true" 
    value="<?php echo $Reserve->ReserveEmail;?>" class="form-control" required/>
                </div>	
                <div class="mb-3">
                <label>ประเภทบุคคล </label><input type="text" name="TypePerson" readonly="true" 
    value="<?php echo $Reserve->TypePerson;?>" class="form-control" required/>
                </div>
                <div class="mb-3">
                <label>การเป็นสมาชิก </label><select name="NotOrMember" class="form-control" required>
    <?php echo "<option value=''></option>";
          echo "<option value='เป็นสมาชิก'>เป็นสมาชิก</option>";
          echo "<option value='ไม่เป็นสมาชิก'>ไม่เป็นสมาชิก</option>";
          
    ?>
</select>
                <div class="mb-3">
                <label>ค่าบริการ </label><input type="int" name="Price"  class="form-control" required/>
                </div>
                <div class="mb-3">
                <label>ไอดีของสนาม </label><input type="int" name="BadmintonID" readonly="true" 
    value="<?php echo $Reserve->BadmintonID;?>" class="form-control" required/>
                </div>
                <div class="mb-3">
                <label>วันที่จอง </label><input type="date" name="ReserveDate"  class="form-control" required/>
                </div>

                </div>	
                <div class="row">
                    <div class="col-sm">
                        <input type="hidden" name="controller" value="HistoryReserve" />
                    </div>
					<div class="col-sm">
                    <a href="./?controller=Reserve&action=index" class="btn btn-outline-danger btn-lg btn-block" role="button">ยกเลิก</a>
                    </div>

                    <div class="col-sm">
                        <button class="btn btn-outline-success btn-lg btn-block" type="submit" name="action" value="addHistoryReserve"> อนุมัติ</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>
    </div>

    <div>
        <br>
    </div>

</body>

</html>













