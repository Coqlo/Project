<html>
<head></head>
<body>
<form method="get" action="">
<label>ชื่อผู้จอง <input type="text" name="ReserveName" readonly="true" 
    value="<?php echo $Reserve->ReserveName;?>"/> </label><br>

<label>เบอร์โทร <input type="text" name="ReserveTel"readonly="true" 
    value="<?php echo $Reserve->ReserveTel;?>" /> </label><br>

<label>อีเมลล์<input type="text" name="ReserveEmail" readonly="true" 
    value="<?php echo $Reserve->ReserveEmail;?>"/> </label><br>

<label>ประเภทบุคคล<input type="text" name="TypePerson" readonly="true" 
    value="<?php echo $Reserve->TypePerson;?>"/> </label><br>

    <label>การเป็นสมาชิก <select name="NotOrMember">
    <?php echo "<option value=''></option>";
          echo "<option value='เป็นสมาชิก'>เป็นสมาชิก</option>";
          echo "<option value='นักเรียนและนิสิต'>นักเรียนและนิสิต</option>";
          
    ?>
</select></label><br>

<label>ค่าบริการ<input type="int" name="Price" /> </label><br>

<label>ไอดีของสนาม<input type="int" name="BadmintonID" readonly="true" 
    value="<?php echo $Reserve->BadmintonID;?>"/> </label><br>

<label>วันที่จอง<input type="date" name="ReserveDate" /> </label><br>

<input type="hidden" name="controller" value="HistoryReserve"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addHistoryReserve"> Save</button>





</body>
</html>




