<html>

<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>

<body>
    <div class="py-5">
        <img class="d-block mx-auto" src="https://cdn.discordapp.com/attachments/611238647932518421/690917696161841192/logo.png" alt="" width="250">
    </div>
    <div class="container">

        <div class="card shadow" style="width: 100%;
  max-width: 600px;
  padding: 15px;
  margin: auto;">
            <h5 class="card-header">อัพเดทอัตราการบริการ</h5>
            <div class="card-body">
                <div class="mb-3">
                    <form method="get" action="">
                        <label>RateBadmintonID </label> <input type="int" name="RateBadmintonID"
        value="<?php echo $RateBadminton->RateBadmintonID; ?>"class="form-control"/>   
                </div>
                <div class="mb-3">
                    <form method="get" action="">
                        <label>ประเภทบุคคล </label> <input type="text" name="TypeRatePerson"
        value="<?php echo $RateBadminton->TypeRatePerson; ?>" class="form-control"/>
                </div>
                <div class="mb-3">
                    <label>อาคาร </label><input type="text" name="TerminalGym"
        value="<?php echo $RateBadminton->TerminalGym; ?>" class="form-control"/>
                </div>
				<div class="mb-3">
                    <label>ค่าสมาชิกต่อปี </label><input type="int" name="PriceMemberPerYear"
        value="<?php echo $RateBadminton->PriceMemberPerYear; ?>" class="form-control"/>
                </div>
				<div class="mb-3">
                    <label>ค่าบริการ(เป็นสามชิก) </label><input type="int" name="PriceMember"
        value="<?php echo $RateBadminton->PriceMember; ?>" class="form-control"/>
                </div>
				<div class="mb-3">
                    <label>ค่าบริการ(ไม่เป็นสามาชิก) </label><input type="int" name="PriceNotMember"
        value="<?php echo $RateBadminton->PriceNotMember; ?>" class="form-control"/>
                </div>
					
				
				<div class="row">
                    <div class="col-sm">
                        <input type="hidden" name="controller" value="RateBadminton" />
                    </div>
					<div class="col-sm">
                        <button class="btn btn-outline-danger btn-lg btn-block" type="submit" name="action" value="index">ยกเลิก</button>
                    </div>

                    <div class="col-sm">
                        <button class="btn btn-outline-success btn-lg btn-block" type="submit" name="action" value="update"> อัพเดท</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>
    </div>

    <div>
        <br>
    </div>

</body>

</html>








