<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
		<div class="container">
			<div><br></div>
			<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
						<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="RateBadminton" aria-describedby="button-addon2">
						<input type="hidden" name="controller" value="RateBadminton" class="form-control" placeholder="ค้นหา" aria-label="RateBadminton" aria-describedby="button-addon2">
						<div class=" input-group-append ">
							<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
						
						<a href=./?controller=RateBadminton&action=newRateBadminton type="button" class="btn btn-primary">เพิ่มอัตราการบริการ</a>
					
					</div>
				</form>
		<table class="shadow table table-hover">
  			<thead class="thead-dark">
    			<tr align='center' >
     			 <th scope="col">ลำดับ</th>
     			 <th scope="col">ประเภท</th>
    			 <th scope="col">TerminalGym</th>
    			 <th scope="col">ราคาสมาชิก/ปี</th>
		  		 <th scope="col">ราคาสมาชิก/ครั้ง</th>
	 			 <th scope="col">ราคาไม่ใช่สมาชิก/ครั้ง</th>
				 <th scope="col">อัพเดท</th>
				 <th scope="col">ลบ</th>
   			   </tr>
  			</thead></tr>
			<tbody style="background-color: #EFEFEF">
<?php foreach($RateBadmintonList as $RateBadminton)
{
	echo"<tr align='center' > 
	<td data-lable='ลำดับ'>$RateBadminton->RateBadmintonID</td>
	<td data-lable='ประเภท'>$RateBadminton->TypeRatePerson</td> 
	<td data-lable='TerminalGym'>$RateBadminton->TerminalGym</td>
	<td data-lable='ราคาสมาชิก/ปี'>$RateBadminton->PriceMemberPerYear</td> 
	<td data-lable='ราคาสมาชิก/ครั้ง'>$RateBadminton->PriceMember</td>
	<td data-lable='ราคาไม่ใช่สมาชิก/ครั้ง'>$RateBadminton->PriceNotMember</td>
	<td data-lable='อัพเดท'><a href=?controller=RateBadminton&action=updateForm&RateBadmintonID=$RateBadminton->RateBadmintonID class='btn btn-outline-warning' role='button' ata-placement='right' title='อัพเดทอัตราการบริการ'>updete</a></td>
	<td data-lable='ลบ'><a href=?controller=RateBadminton&action=deleteConfirm&RateBadmintonID=$RateBadminton->RateBadmintonID class='btn btn-outline-danger' role='button' ata-placement='right' title='ลบอัตราการบริการ'>delete</a></td><tr>";
}
echo "</table>";
?>
				</tbody>
			</div>
	</body>

</html>
