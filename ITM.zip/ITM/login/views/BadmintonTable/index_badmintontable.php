<html>
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>
	<style>
body  {
	width:100%;
  background-image: url("https://cdn.discordapp.com/attachments/611238647932518421/690914863048032306/logo.jpg") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
	background-position: center;
}
</style>
	<body >
		<div class="container">
			<div><br></div>
				<form method="get" action="">
					<div class=" shadow input-group mb-3 " >
					<input type="text" name="key"class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
					<input type="hidden" name="controller" value="BadmintonTable" class="form-control" placeholder="ค้นหา" aria-label="Recipient's username" aria-describedby="button-addon2">
						<div class=" input-group-append ">
						<button class="btn btn btn-secondary" type="submit" name="action" value="search" id="button-addon2">Search</button>
						</div>
					
				</div>
				</form>
			
		<div class=" shadow div2" >
			<table class="table table-hover">
  				<thead class="thead-dark">
		  		  <tr align="center">
      				<th scope="col">BadmintonID</th>
     				<th scope="col">สนามแบดมินตัน</th>
    				<th scope="col">อาคาร</th>
      				<th scope="col">เวลาเริ่ม</th>
	  				<th scope="col">เวลาสิ้นสุด</th>
	  				<th scope="col">สถานะ</th>
   				</tr>
  				</thead>
				<tbody style="background-color: #EFEFEF">
		
<?php foreach($BadmintonTableList as $BadmintonTable)
{
	echo "<tr align='center' >
			<td data-lable='BadmintonID'>$BadmintonTable->BadmintonID </td>
			<td data-lable='สนามแบดมินตัน'>$BadmintonTable->BadmintonCourt </td>
			<td data-lable='อาคาร'>$BadmintonTable->TerminalGym </td>
			<td data-lable='เวลาเริ่ม'>$BadmintonTable->TimeStart </td>
			<td data-lable='เวลาสิ้นสุด'>$BadmintonTable->TimeFinish </td>
			
			";
	if ($BadmintonTable->StatusCourt == "ว่าง")
	{
		echo "
		<td data-lable='สถานะ' role='button'  class='btn btn-success' aria-disabled='true' >$BadmintonTable->StatusCourt</td>
		</tr>
		";
	}
	if ($BadmintonTable->StatusCourt == "จองแล้ว")
	{
		echo "
		<td data-lable='สถานะ' role='button' class='btn btn-danger' aria-disabled='true' >$BadmintonTable->StatusCourt</td>
		</tr>
		";
	}
	if ($BadmintonTable->StatusCourt == "กำลังใช้งาน")
	{
		echo "
		<td data-lable='สถานะ' class='btn btn-warning' role='button' aria-disabled='true' >$BadmintonTable->StatusCourt</td>
		</tr>
		";
	}
}
	echo "</table>";

	
	
?>
					</tbody>
			</div>
	</body>
</html>

