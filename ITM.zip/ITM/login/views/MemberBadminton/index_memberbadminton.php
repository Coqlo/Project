<table border = 1>
<tr> <td>MemberBadmintonID</td><td>MemberName</td><td>MemberAddress</td><td>MemberTel</td><td>MemberEmail</td><td>TypeMember</td><td>อัพเดท</td><td>ลบ</td></tr>

<form method="get" action="">
	<input type="text" name="key">
	<input type="hidden" name="controller" value="MemberBadminton"/>
	<button type="submit" name="action" value="search">
Search</button>
</form>
<?php foreach($MemberBadmintonList as $MemberBadminton)
{
	echo"<tr> <td>$MemberBadminton->MemberBadmintonID</td>
	<td>$MemberBadminton->MemberName</td> 
	<td>$MemberBadminton->MemberAddress</td>
	<td>$MemberBadminton->MemberTel</td> 
	<td>$MemberBadminton->MemberEmail</td>
	<td>$MemberBadminton->TypeMember</td>
	<td><a href=?controller=MemberBadminton&action=updateForm&MemberBadmintonID=$MemberBadminton->MemberBadmintonID>updete</a></td>
	<td><a href=?controller=MemberBadminton&action=deleteConfirm&MemberBadmintonID=$MemberBadminton->MemberBadmintonID>delete</a></td>"; 

}

echo "</table>";
?>
<html>
<head></head>
<body>
    เพิ่มสมาชิก[<a href=?controller=MemberBadminton&action=newMemberBadminton>Click</a>]
</body>
</html>	
