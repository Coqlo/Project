<?php echo "<br>Are you sure to delete this MemberBadminton <br>
            <br>$MemberBadminton->MemberBadmintonID $MemberBadminton->MemberName $MemberBadminton->MemberAddress $MemberBadminton->MemberTel $MemberBadminton->MemberEmail $MemberBadminton->TypeMember <br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="MemberBadminton"/>
    <input type="hidden" name="MemberBadmintonID" value="<?php echo $MemberBadminton->MemberBadmintonID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button>
</form>