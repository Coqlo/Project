<html>
<head></head>
<body>
<form method="get" action="">
<label> MemberBadmintonID<input type="int" name="MemberBadmintonID" /> </label><br>
<label>MemberName <input type="text" name="MemberName" /> </label><br>
<label>MemberAddress<input type="text" name="MemberAddress" /> </label><br>
<label>MemberTel<input type="int" name="MemberTel" /> </label><br>
<label>MemberEmail<input type="int" name="MemberEmail" /> </label><br>
<label>TypeMember
<select name="TypeMember" id="TypeMember">
  <option value="">Choose..</option>
  <option value="เด็กอายุต่ำกว่า13">เด็กอายุต่ำกว่า13</option>
  <option value="นักเรียนและนิสิต">นักเรียนและนิสิต</option>
  <option value="บุคลากร">บุคลากร</option>
  <option value="บุคคลทั่วไป">บุคคลทั่วไป</option>
</select> <br>


<input type="hidden" name="controller" value="MemberBadminton"/>
<button type="submit" name="action" value="index"> Back</button>
<button type="submit" name="action" value="addMemberBadminton"> Save</button>

</form>



</body>
</html>




