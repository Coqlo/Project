ื
<!DOCTYPE html>
<html>
	<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	<link href="../../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
	</head>
		<style>
body  {
	width:100%;
  background-image: url("https://cdn.discordapp.com/attachments/611238647932518421/691312058603405382/bgbule.jpg") ;
  background-repeat: no-repeat;
  background-attachment: fixed;
	background-size: cover;
	background-position: center;
	
}
</style>

<body>
  		<div class=" col-md-5 p-lg-5 mx-auto my-5" style="text-align: center;">
    		<h1 class="display-4 font-weight-normal">Hello</h1>
   			 <a style="font-size: 32px">Admin Page</a>
  		</div>
</body>
</html>