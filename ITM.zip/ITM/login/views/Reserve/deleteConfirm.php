<?php echo "<br>Are you sure to delete this Reserve <br>
            <br>ReserveID:$Reserve->ReserveID ReserveName:$Reserve->ReserveName   <br>";?>
<form method="get" action="">"
    <input type="hidden" name="controller" value="Reserve"/>
    <input type="hidden" name="ReserveID" value="<?php echo $Reserve->ReserveID; ?>" />
    <button type="submit" name="action" value="index">Back</button>
    <button type="submit" name="action" value="delete">Delete</button> 
</form>