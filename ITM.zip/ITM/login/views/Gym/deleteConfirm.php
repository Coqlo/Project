
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
</head>
<style>
$('#input_startGym').pickaGym({
// 12 or 24 hour
twelvehour: true,
});
</style>

<body>
    <div class="py-5">
        <img class="d-block mx-auto" src="https://cdn.discordapp.com/attachments/611238647932518421/690917696161841192/logo.png" alt="" width="250">
    </div>
    <div class="container">

        <div class="card shadow" style="width: 100%;
  max-width: 600px;
  padding: 15px;
  margin: auto;">
            <h5 class="card-header">ลบอาคาร</h5>
            <div class="card-body">
                <div class="mb-3">
                    <form method="get" action="">
                    <label>GymID </label> <input type="int" name="GymID"
        value="<?php echo $Gym->GymID; ?>" class="form-control" readonly="true"/>   
                </div>
                <div class="mb-3">
                    <form method="get" action="">
                    <label>GymName </label> <input type="text" step="2" name="GymName"
        value="<?php echo $Gym->GymName; ?>" class="form-control" readonly="true"/>
                </div>
				<div class="row">
                    <div class="col-sm">
                        <input type="hidden" name="controller" value="Gym"/>
                    </div>
					<div class="col-sm">
                        <button class="btn btn-outline-danger btn-lg btn-block" type="submit" name="action" value="index">ยกเลิก</button>
                    </div>

                    <div class="col-sm">
                        <button class="btn btn-outline-success btn-lg btn-block" type="submit" name="action" value="delete"> ลบอาคาร</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    </div>
    </div>

    <div>
        <br>
    </div>

</body>

</html>








