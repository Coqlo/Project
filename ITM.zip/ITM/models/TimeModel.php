<?php
Class Time{
Public $TimeID;
Public $TimeStart;
Public $TimeFinish;


Public function Time($TimeID,$TimeStart,$TimeFinish)
{            
           $this->TimeID = $TimeID;
           $this->TimeStart = $TimeStart;
           $this->TimeFinish = $TimeFinish;
           ;
}
public static function getAll()
{
	$TimeList=[];
	require_once("connection_connect.php");
	$sql = "select * from Time";
	$result = $conn->query($sql);
	
	while ($my_row=$result->fetch_assoc())
		{

			$TimeID=$my_row['TimeID'];
			$TimeStart=$my_row['TimeStart'];
			$TimeFinish=$my_row['TimeFinish'];
			
			$TimeList[]=new Time($TimeID,$TimeStart,$TimeFinish);
		}
		require("connection_close.php");
		return $TimeList;
}
}?>