<?php class Gym{
	public $GymID,$GymName;
	public function Gym($GymID,$GymName)
	{
		$this->GymID = $GymID;
		$this->GymName = $GymName;
		
	}
	public static function getAll()
	{
		$GymList=[];
		require("connection_connect.php");
		$sql="select * from Gym";
		$result=$conn->query($sql);
		
		while ($my_row=$result->fetch_assoc())
		{
			$GymID=$my_row['GymID'];
			$GymName=$my_row['GymName'];
			
			$GymList[]=new Gym($GymID,$GymName);
		}
		require("connection_close.php");
		return $GymList;
		
		
	}
}?>