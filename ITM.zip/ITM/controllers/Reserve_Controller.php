<?php 
class ReserveController
{	
	public function index()
	{	$ReserveList= Reserve::getAll();
		require_once('views/Reserve/index_reserve.php');
	}

	public function newReserve()
	{
		$id=$_GET['BadmintonID'];
		$BadmintonTable = BadmintonTable::get($id);
		$BadmintonTableList=BadmintonTable::getAll();
		$BadmintonList=Badminton::getAll();
		require_once("views/Reserve/newReserve.php");
		
	}
	public function addReserve()
	{
		$ReserveName=$_GET['ReserveName'];
		$ReserveTel=$_GET['ReserveTel'];
		$ReserveEmail=$_GET['ReserveEmail'];
		$TypePerson = $_GET['TypePerson'];
		$BadmintonCourt=$_GET['BadmintonCourt'];
		$TerminalGym=$_GET['TerminalGym'];
		$TimeStart=$_GET['TimeStart'];
		$TimeFinish=$_GET['TimeFinish'];
		$BadmintonID=$_GET['BadmintonID'];
		
		Reserve::Add($ReserveName,$ReserveTel,$ReserveEmail,$TypePerson,$BadmintonCourt,$TerminalGym,$TimeStart,$TimeFinish,$BadmintonID);
		ReserveController::index();
	
	}
	
}?>