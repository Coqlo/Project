<?php class TimeController
{
	public function index()
	{
		$TimeList=Time::getAll();
		require_once('views/Time/index_time.php');
	}
}?>