<?php class GymController
{
	public function index()
	{
		$GymList=Gym::getAll();
		require_once('views/Gym/index_gym.php');
	}
}?>